# Custom Error Types
class HMMError(Exception):
    pass


class HMMValidationError(HMMError):
    pass
